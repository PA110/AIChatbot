"""
Seed script — Ingest sample documents into the knowledge base.
Run once after setup: python seed_sample_docs.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from utils.rag_engine import ingest_document, DOCUMENTS_PATH

DOCUMENTS_PATH.mkdir(parents=True, exist_ok=True)

samples = [
    ("sample_docs/Remote_Work_Policy.txt",    "HR & People"),
    ("sample_docs/IT_Security_Guidelines.txt","IT & Security"),
    ("sample_docs/Employee_Benefits_Guide.txt","HR & People"),
]

print("Seeding sample documents...\n")
for path_str, category in samples:
    p = Path(path_str)
    if not p.exists():
        print(f"  SKIP  {path_str} (not found)")
        continue
    import shutil
    dest = DOCUMENTS_PATH / p.name
    shutil.copy(p, dest)
    entry = ingest_document(dest, category=category)
    print(f"  OK    {entry['filename']}  |  {entry['chunks']} chunks  |  {entry['words']:,} words")

print("\nDone! Start the app with: streamlit run app.py")
